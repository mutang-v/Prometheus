import argparse
import json
import sys
from pathlib import Path

from prometheus.experiment import run_demo, run_research
from prometheus.api_client import load_config, call_model
from prometheus.storage import save_run

ROOT = Path(__file__).resolve().parent

def main():
    parser = argparse.ArgumentParser(description="Project Prometheus v0.1")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--check", action="store_true", help="检查本地 Python 环境")
    group.add_argument("--demo", action="store_true", help="运行免费本地演示实验")
    group.add_argument("--check-api", action="store_true", help="发送一次 API 测试请求")
    group.add_argument("--goal", type=str, help="研究目标（v0.1 仅支持内置参数搜索实验）")
    parser.add_argument("--rounds", type=int, default=1, help="研究轮数，限制为 1-3")
    args = parser.parse_args()

    if args.check:
        print("Prometheus v0.1 本地环境检查")
        print(f"Python: {sys.version.split()[0]}")
        print(f"项目目录: {ROOT}")
        print(f"配置模板存在: {(ROOT / 'config.example.json').exists()}")
        print("本地检查通过；未调用 API，未修改系统配置。")
        return

    if args.demo:
        result = run_demo()
        path = save_run(ROOT, result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        print(f"\n记录已保存：{path}")
        return

    if args.check_api:
        cfg = load_config(ROOT)
        response = call_model(cfg, "Reply with exactly: PROMETHEUS_API_OK")
        print("API 请求成功。模型回复：")
        print(response)
        return

    if args.goal:
        if not 1 <= args.rounds <= 3:
            parser.error("--rounds 只能是 1 到 3，防止意外消耗 API 额度。")
        cfg = load_config(ROOT)
        result = run_research(cfg, args.goal, args.rounds)
        path = save_run(ROOT, result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        print(f"\n记录已保存：{path}")

if __name__ == "__main__":
    main()
