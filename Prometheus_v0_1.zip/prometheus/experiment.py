import json
import math
import re
from datetime import datetime, timezone
from .api_client import call_model

def score_parameter(x: float) -> float:
    # 固定、可复现的玩具优化任务：寻找最接近 7.3 的参数。
    # 分数越高越好，最大理论分数为 1。
    return 1.0 / (1.0 + (x - 7.3) ** 2)

def run_demo():
    baseline_x = 2.0
    candidates = [0.0, 2.0, 4.0, 6.0, 7.0, 7.5, 8.0, 10.0]
    scored = [{"x": x, "score": score_parameter(x)} for x in candidates]
    best = max(scored, key=lambda item: item["score"])
    return {
        "project": "Prometheus",
        "mode": "local_demo",
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "objective": "在固定候选集合中最大化 score_parameter(x)",
        "baseline": {"x": baseline_x, "score": score_parameter(baseline_x)},
        "candidates": scored,
        "best_candidate": best,
        "improved_over_baseline": best["score"] > score_parameter(baseline_x),
        "note": "仅用于验证实验、评分和记录闭环，不代表通用智能能力。"
    }

def _extract_json(text):
    # 接受裸 JSON 或 ```json ... ```，拒绝其他形式。
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.I)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    start, end = cleaned.find("{"), cleaned.rfind("}")
    if start < 0 or end <= start:
        raise ValueError("模型没有返回 JSON 对象。")
    return json.loads(cleaned[start:end+1])

def run_research(cfg, goal: str, rounds: int):
    # 模型只能提出数字候选；本地评分器负责客观评估，绝不执行模型生成的代码。
    domain = [i / 2 for i in range(0, 21)]  # 0.0 到 10.0，步长 0.5
    history = []
    for idx in range(rounds):
        prompt = (
            "研究目标：\n" + goal + "\n\n"
            "当前实验是一个受控的参数搜索演示。可选参数 x 只能从以下集合中选择："
            + json.dumps(domain) + "\n"
            "本地评分函数是 score=1/(1+(x-7.3)^2)，越高越好。\n"
            "请只返回 JSON：{\"candidate_x\": 数字, \"reason\": \"简短可检验理由\"}。\n"
            "不要输出代码，不要增加其他字段。"
        )
        raw = call_model(cfg, prompt)
        parsed = _extract_json(raw)
        x = float(parsed["candidate_x"])
        if x not in domain:
            raise ValueError(f"模型候选参数 {x} 不在允许集合中，已拒绝执行。")
        score = score_parameter(x)
        history.append({
            "round": idx + 1, "candidate_x": x, "score": score,
            "reason": str(parsed.get("reason", ""))[:500]
        })
    baseline = {"x": 2.0, "score": score_parameter(2.0)}
    best = max(history, key=lambda item: item["score"])
    return {
        "project": "Prometheus", "mode": "api_research",
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "goal": goal, "baseline": baseline, "rounds_requested": rounds,
        "round_results": history,
        "best_candidate": {"x": best["candidate_x"], "score": best["score"]},
        "improved_over_baseline": best["score"] > baseline["score"],
        "note": "模型负责提出候选参数；本地固定评分器负责评估。当前仅为玩具任务。"
    }
