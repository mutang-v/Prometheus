import json
from datetime import datetime, timezone
from pathlib import Path

def save_run(root: Path, result: dict) -> Path:
    out = root / "runs"
    out.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    mode = result.get("mode", "run")
    path = out / f"{stamp}_{mode}.json"
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return path
